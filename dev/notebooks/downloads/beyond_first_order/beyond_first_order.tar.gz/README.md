# beyond_first_order — local inspection

This directory contains untrusted notebook code. Verify the files before opening them, then read
the source before running it. The four steps below are the whole story, in order; the site this
bundle came from shows the same chain.

## 1. Download

You already have this directory. If you also kept the archive it came from, verify
that before trusting anything extracted from it:

```julia
using DocumenterSlate
verify_slate_bundle("beyond_first_order.tar.gz")
```

## 2. Verify

Check the files against the checksums the bundle carries:

```sh
sha256sum -c SHA256SUMS
```

or, equivalently, from Julia:

```julia
using DocumenterSlate
verify_slate_bundle(".")
```

Then read `PROVENANCE.toml`. Checksums prove the bytes are intact; they say nothing
about *origin*. Compare `repository` and `git_sha` against the repository you
actually trust, and treat `ci_produced = false` as a locally built bundle.
Provenance is build metadata, not a signature — anyone can serve a well-formed
bundle.

## 3. Read

A KaimonSlate notebook is plain Julia source, and reading `beyond_first_order.jl` is the only
step that tells you what the code would actually do. KaimonSlate can also serve a static
view that starts no worker and evaluates no cell:

```julia
using KaimonSlate
KaimonSlate.serve_notebook("beyond_first_order.jl"; inactive = true)
```

## 4. Run deliberately

Only after steps 2 and 3. Instantiating the environment may run package build scripts,
and opening the notebook in live mode may execute anything. The three routes below are
ordered by how much of your host they expose.

*Isolated container* (recommended) — keeps package installation and notebook inspection
off the host. The image opens the notebook in inactive mode; it evaluates no cell:

```sh
podman build -t beyond_first_order-inspect . && podman run --rm -it -p 8765:8765 beyond_first_order-inspect
```

Alternatively, open `devcontainer.json` in a compatible editor.

*Pinned host environment* — uses the published project and manifest, but runs package
build scripts and notebook code with your host account's permissions:

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. -e 'using KaimonSlate; KaimonSlate.serve_notebook("beyond_first_order.jl")'
```

*Native application* — installing and opening the application executes code with your
host account's permissions:

```sh
julia -e 'using Pkg; Pkg.Registry.add(Pkg.Registry.RegistrySpec(url="https://github.com/kahliburke/SlateRegistry")); Pkg.Apps.add("KaimonSlate")'
slate --own beyond_first_order.jl
```

A container reduces access to the host; it does not make untrusted code harmless. Review
the mount and network permissions too.

